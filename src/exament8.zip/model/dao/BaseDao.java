package model.dao;

public class BaseDao {
}
